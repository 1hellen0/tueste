# Caso A — Tueste: Análisis de Unit Economics y Simulación Financiera

Este proyecto implementa la solución completa, rigurosa y auditada para el **Caso A — Tueste**, cumpliendo los requisitos oficiales de los **Niveles 1, 2 y 3** establecidos en el documento académico de 13 páginas y su rúbrica de evaluación.

---

## 📌 Resumen de los Tres Niveles

### Nivel 1: Calculadora Financiera en Hoja de Cálculo (`Calculadora_Tueste_Nivel_1.xlsx`)
- **5 Pestañas Obligatorias:** `Supuestos`, `Resultados`, `Escenarios`, `Curva de caja` y `Recomendación`.
- **Fórmulas 100% Vivas:** Sin valores hardcodeados en celdas de cálculo. Compatible con Excel y Google Sheets.
- **Unit Economics Auditados:** CM1 ($23,12 USD), CM2 ($15,89 USD suelto / $12,64 USD suscripción), CAC Ads ($48,48 USD), CAC Real ($54,55 USD), LTV 12 meses ($54,80 USD) y Payback exacto en el **Mes 12** (+ $0,25 USD).
- **Separación de Supuestos:** Mantiene el mix oficial 85/15 en la recomendación base y aísla la hipótesis de optimización 80/20.
- **Curva de Caja:** Gráfico nativo embebido con 4 curvas comparativas y línea de corte en cero.
- **Recomendación Ejecutiva:** Demostración analítica de por qué **NO FIRMAR** con la agencia Impulso Digital y desglose de 4 errores reales de modelos de IA.

### Nivel 2: Tablero Financiero Interactivo en React
- **Stack Tecnológico:** React 18, Vite 6, Tailwind CSS, Lucide React y Recharts (sin TypeScript).
- **Diseño Profesional:** Interfaz moderna con temática de café de especialidad (tonos bosque profundo `#0a1a12`, acentos dorados `#d97706`).
- **Controles Dinámicos:** Sliders y selectores continuos para inversión publicitaria, precios, costos variables, mix y churn, con recálculo dinámico instantáneo (`useMemo`).
- **Botón de Restauración:** Devuelve con un solo clic los parámetros exactos de Septiembre (Hoy).
- **4 Gráficos Recharts Obligatorios:**
  1. *Curva de Caja del Cliente:* Trayectoria del margen acumulado mes a mes vs. CAC Real.
  2. *LTV vs. CAC:* Comparativa visual de ratios con directrices 1:1 y 3:1.
  3. *Saturación de Meta & CAC Marginal:* Curva de rendimientos decrecientes por tramos ($40 a $267 USD).
  4. *La Trampa del ROAS:* Desacoplamiento explícito entre el ROAS reportado por Meta (3,00x) y el ROAS de adquisición real (0,70x) frente al Break-Even (2,14x).
- **Simulación de Tesorería:** Proyección mensual de la empresa demostrando el agotamiento de caja en Mes 3 ($1.212 USD) y quiebra técnica en Mes 4 (-$8.248 USD) bajo la propuesta de la agencia.
- **Modal de Auditoría a Mano:** Desglose aritmético paso a paso con fórmulas visibles.

### Nivel 3: Simulador Dinámico a 24 Meses por Cohortes
- **Modelo de Cohortes Completo:** 24 cohortes mensuales modeladas de forma independiente para pedidos sueltos (calendario oficial M1-M12 y residual 0,10 pedidos/mes en M13-M24) y suscriptores con churn del 9% mensual.
- **Captación de Clientes:** Interpolación lineal continua sobre la tabla histórica de Meta partiendo de (0,0), más los 47 clientes orgánicos mensuales fijos.
- **Auditoría Automática de Restricciones Oficiales:**
  - *Regla 1 (Piso de Seguridad):* La caja nunca baja de $5.000 USD en ningún mes.
  - *Regla 2 (Sostenibilidad de Pauta):* En meses 13 a 24, la inversión de cada mes no puede ser inferior al promedio de los meses 1 a 12.
- **Comparativa de los 4 Planes Estratégicos:**
  - *Plan 1 (Fijo Tradicional $8k):* Caja M24 = $79.596,45 USD | Mínima = $24.447,51 USD | Subs = 316,6.
  - *Plan 2 (Agencia $16k + 30% desc):* Caja M24 = -$72.915,52 USD | Falla Regla 1 en Mes 3 ($1.212 USD) y quiebra en Mes 4 (-$8.248 USD).
  - *Plan 3 (Propio 1 - Pauta Eficiente $6k):* Caja M24 = **$132.069,98 USD** 🏆 (**Ganador Absoluto por Caja**).
  - *Plan 4 (Propio 2 - Escalonado $6k-$8k):* Caja M24 = **$127.362,10 USD** | Subs = **312,3** 🌟 (**Alternativa Estratégica Superior en Retención**).
- **Análisis de la Segunda Tostadora ($14.000 USD en Mes 3):** Demostración de viabilidad en efectivo para Planes 3 y 4 manteniendo la tesorería por encima de $19.400 USD sin requerir deuda ni capital externo.
- **Ficha Ejecutiva para Pitch de 2 Minutos:** 4 pilares financieros para presentar al inversionista (tío de Diego).

---

## 🚀 Requisitos Previos e Instalación

### Requisitos del Sistema
- **Node.js:** Versión 18.0 o superior (verificar con `node -v`).
- **Python:** Versión 3.8 o superior con librería `openpyxl` (opcional, para ejecutar la suite de pruebas del archivo Excel: `pip install openpyxl`).

### Pasos de Instalación

1. Clonar o extraer el proyecto en un directorio local:
   ```bash
   cd tueste
   ```

2. Instalar dependencias de Node:
   ```bash
   npm install
   ```

---

## 💻 Comandos de Ejecución y Pruebas

### 1. Iniciar el Tablero Interactivo (Modo Desarrollo)
```bash
npm run dev
```
Abre tu navegador en: `http://localhost:5173/`

### 2. Ejecutar la Suite de Pruebas Automatizadas
- **Prueba del Libro Excel Nivel 1:**
  ```bash
  npm run test:calc
  ```
  Verifica las 5 hojas obligatorias, fórmulas, calendario de pedidos (3,00) y payback en Mes 12.

- **Prueba de Consistencia Matemática Niveles 2 y 3:**
  ```bash
  npm run test:audit
  ```
  Verifica LTV exacto ($54,80), CAC Real ($54,55), interpolación de Meta, los 4 planes de cohortes y el impacto de la tostadora.

### 3. Generar la Compilación de Producción
```bash
npm run build
```
Genera la carpeta `dist/` con el código minificado listo para despliegue.

---

## 📂 Estructura Principal del Proyecto

```text
├── Calculadora_Tueste_Nivel_1.xlsx    # Libro Excel oficial (Nivel 1)
├── src/
│   ├── components/
│   │   ├── Sidebar.jsx                # Navegación lateral con selector de niveles
│   │   ├── Header.jsx                 # Barra superior y botón de restauración
│   │   ├── ValueAlerts.jsx            # Banners reactivos de destrucción de caja
│   │   ├── KpiGrid.jsx                # Tarjetas KPI con semáforos tricolor
│   │   ├── ControlPanel.jsx           # Sliders y toggles dinámicos
│   │   ├── ChartsSection.jsx          # 4 Gráficos Recharts obligatorios
│   │   ├── ScenarioComparisonTable.jsx# Matriz comparativa de escenarios
│   │   ├── CompanyCashSimulation.jsx  # Simulación de tesorería mensual (quiebra agencia)
│   │   ├── CohortSimulator24M.jsx     # Simulador oficial de cohortes 24M (Nivel 3)
│   │   ├── AiErrorsSection.jsx        # Documentación de 4 errores reales de IA
│   │   └── ManualAuditModal.jsx       # Modal de auditoría con cálculos a mano
│   ├── utils/
│   │   └── financialFormulas.js       # Motor puro de cálculo financiero y cohortes
│   ├── App.jsx                        # Componente raíz SPA
│   ├── main.jsx                       # Punto de entrada de React
│   └── index.css                      # Estilos globales y tokens Tailwind
├── test_calculator.py                 # Suite de prueba para el archivo Excel
├── test_audit_levels.js               # Suite de prueba para los 3 niveles
├── datos_tueste.json                  # Base de datos JSON extraída del PDF
├── REQUISITOS_TUESTE.md               # Requisitos oficiales y rúbrica académica
├── BITACORA_DESARROLLO.md             # Registro cronológico completo de auditoría
└── package.json                       # Configuración y scripts npm
```

---

## ⚖️ Dictamen Académico Final
- **Nivel 1:** 100% Cumplido.
- **Nivel 2:** 100% Cumplido.
- **Nivel 3:** 100% Cumplido.
- **Conciliación Matemática:** Margen de discrepancia entre Excel y React menor al 0,1%.
